$computers = @("PC1", "PC2", "PC3")  # Replace with your actual device names
$networkOutputPath = "\\server\share\OfficeLicReports"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outputFile = Join-Path $networkOutputPath "Combined_OfficeLicenses_$timestamp.csv"

$allResults = @()

foreach ($comp in $computers) {
    try {
        Write-Host "Collecting data from $comp..."
        $results = Invoke-Command -ComputerName $comp -ScriptBlock {
            function Get-LicenseData {
                Param([string]$mode)

                $results = @()

                if ($mode -eq "NUL") {
                    $licensePath = "${env:LOCALAPPDATA}\Microsoft\Office\Licenses"
                } elseif ($mode -eq "Device") {
                    $licensePath = "${env:PROGRAMDATA}\Microsoft\Office\Licenses"
                }

                if (-not (Test-Path $licensePath)) {
                    return $results
                }

                $licenseFiles = Get-ChildItem -Path $licensePath -Recurse -File
                if ($licenseFiles.Count -eq 0) {
                    return $results
                }

                foreach ($file in $licenseFiles) {
                    $raw = Get-Content -Encoding Unicode -Path $file.FullName | ConvertFrom-Json
                    $decoded = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($raw.License)) | ConvertFrom-Json

                    $userId = $decoded.Metadata.UserId
                    $email = $null
                    try {
                        $identityReg = Get-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Office\16.0\Common\Identity\Identities\${userId}*" -ErrorAction Stop
                        $email = $identityReg.EmailAddress
                    } catch {}

                    $state = if ((Get-Date) -gt (Get-Date $decoded.MetaData.NotAfter)) {
                        "RFM"
                    } elseif (-not $decoded.ExpiresOn -or (Get-Date) -lt (Get-Date $decoded.ExpiresOn)) {
                        "Licensed"
                    } else {
                        "Grace"
                    }

                    $obj = [PSCustomObject]@{
                        ComputerName          = $env:COMPUTERNAME
                        Version               = $file.Directory.Name
                        Type                  = "$mode|$($decoded.LicenseType)"
                        Product               = $decoded.ProductReleaseId
                        Acid                  = $decoded.Acid
                        Email                 = $email
                        LicenseState          = $state
                        EntitlementStatus     = $decoded.Status
                        EntitlementExpiration = $decoded.ExpiresOn
                        ReasonCode            = $decoded.ReasonCode
                        NotBefore             = $decoded.Metadata.NotBefore
                        NotAfter              = $decoded.Metadata.NotAfter
                        NextRenewal           = $decoded.Metadata.RenewAfter
                        TenantId              = $decoded.Metadata.TenantId
                        LicenseId             = $decoded.LicenseId
                    }

                    $results += $obj
                }

                return $results
            }

            $nul = Get-LicenseData -mode "NUL"
            $device = Get-LicenseData -mode "Device"
            return $nul + $device
        }

        if ($results) {
            $allResults += $results
        } else {
            Write-Warning "No data from $comp"
        }
    } catch {
        Write-Warning "Failed to query $comp: $_"
    }
}

if ($allResults.Count -gt 0) {
    $allResults | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8
    Write-Host "✅ Combined license report written to: $outputFile"
} else {
    Write-Warning "No results collected from any computer."
}
